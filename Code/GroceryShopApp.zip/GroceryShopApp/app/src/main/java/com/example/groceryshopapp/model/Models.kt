package com.example.groceryshopapp.model

data class Item(
    val id: Int,
    val shopId: Int,
    var name: String,
    var price: Double,
    var quantity: Int,
    val iconResId: Int     // NEW FIELD FOR VECTOR DRAWABLE ICON
)

data class Shop(
    val id: Int,
    val name: String,
    val ownerName: String,
    val city: String,
    val latitude: Double,
    val longitude: Double,
    val items: MutableList<Item> = mutableListOf()
)

data class CartItem(
    val shopId: Int,
    val itemId: Int,
    var quantity: Int
)

data class OrderItem(
    val itemName: String,
    val quantity: Int,
    val priceEach: Double
)

data class Order(
    val id: Int,
    val shopId: Int,
    val totalAmount: Double,
    val distanceKm: Double,
    val etaMinutes: Int,
    val items: List<OrderItem>,
    val customerLat: Double,
    val customerLng: Double,
    val timestampMillis: Long = System.currentTimeMillis()
)
