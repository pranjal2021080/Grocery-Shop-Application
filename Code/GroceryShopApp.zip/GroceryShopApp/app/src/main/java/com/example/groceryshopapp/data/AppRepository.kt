package com.example.groceryshopapp.data

import com.example.groceryshopapp.model.*
import kotlin.math.*
import com.example.groceryshopapp.R

// ---------- USER & ROLES ----------

enum class UserRole {
    CUSTOMER,
    OWNER
}

data class User(
    val username: String,
    val password: String,
    val role: UserRole,
    val shopId: Int? = null
)

// ---------- REPOSITORY ----------

object AppRepository {

    private val shops: MutableList<Shop> = mutableListOf()
    private val cart: MutableList<CartItem> = mutableListOf()
    private val orders: MutableList<Order> = mutableListOf()
    private var nextItemId = 1
    private var nextOrderId = 1

    // DEMO USERS
    private val users = mutableListOf(
        User("cust1", "cust1", UserRole.CUSTOMER),
        User("cust2", "cust2", UserRole.CUSTOMER),
        User("owner1", "owner1", UserRole.OWNER, 1),
        User("owner2", "owner2", UserRole.OWNER, 2),
        User("owner3", "owner3", UserRole.OWNER, 3),
        User("owner4", "owner4", UserRole.OWNER, 4),
        User("owner5", "owner5", UserRole.OWNER, 5)
    )

    private var currentUser: User? = null

    fun login(username: String, password: String, role: UserRole): Boolean {
        val user = users.find {
            it.role == role &&
                    it.username.equals(username.trim(), ignoreCase = true) &&
                    it.password == password.trim()
        }
        currentUser = user
        return user != null
    }

    fun logout() {
        currentUser = null
    }

    fun getCurrentUser(): User? = currentUser

    // ---------- INITIAL SAMPLE DATA (5 SHOPS × 30 ITEMS WITH ICONS) ----------

    init {
        initSampleData()
    }

    // Item template with icons
    private data class ItemTemplate(
        val name: String,
        val price: Double,
        val iconResId: Int
    )

    // EXACTLY 30 ITEMS HERE
    private fun groceryTemplates(): List<ItemTemplate> = listOf(
        // GRAINS / DAL (10)
        ItemTemplate("Basmati Rice 1kg", 60.0, R.drawable.ic_grains),      // 1
        ItemTemplate("Brown Rice 1kg", 55.0, R.drawable.ic_grains),        // 2
        ItemTemplate("Wheat Atta 5kg", 220.0, R.drawable.ic_grains),       // 3
        ItemTemplate("Maida 1kg", 35.0, R.drawable.ic_grains),             // 4
        ItemTemplate("Sooji 1kg", 32.0, R.drawable.ic_grains),             // 5
        ItemTemplate("Chana Dal 1kg", 70.0, R.drawable.ic_grains),         // 6
        ItemTemplate("Moong Dal 1kg", 85.0, R.drawable.ic_grains),         // 7
        ItemTemplate("Toor Dal 1kg", 95.0, R.drawable.ic_grains),          // 8
        ItemTemplate("Poha 1kg", 45.0, R.drawable.ic_grains),              // 9
        ItemTemplate("Oats 1kg", 90.0, R.drawable.ic_grains),              // 10

        // DAIRY (4) → 14
        ItemTemplate("Milk 1L", 52.0, R.drawable.ic_dairy),                // 11
        ItemTemplate("Curd 500g", 40.0, R.drawable.ic_dairy),              // 12
        ItemTemplate("Paneer 200g", 75.0, R.drawable.ic_dairy),            // 13
        ItemTemplate("Butter 100g", 48.0, R.drawable.ic_dairy),            // 14

        // VEGETABLES (5) → 19
        ItemTemplate("Potato 1kg", 25.0, R.drawable.ic_veggies),           // 15
        ItemTemplate("Onion 1kg", 30.0, R.drawable.ic_veggies),            // 16
        ItemTemplate("Tomato 1kg", 35.0, R.drawable.ic_veggies),           // 17
        ItemTemplate("Carrot 1kg", 40.0, R.drawable.ic_veggies),           // 18
        ItemTemplate("Cucumber 1kg", 28.0, R.drawable.ic_veggies),         // 19

        // FRUITS (4) → 23
        ItemTemplate("Apple 1kg", 120.0, R.drawable.ic_fruits),            // 20
        ItemTemplate("Banana (6 pc)", 30.0, R.drawable.ic_fruits),         // 21
        ItemTemplate("Orange 1kg", 80.0, R.drawable.ic_fruits),            // 22
        ItemTemplate("Grapes 1kg", 90.0, R.drawable.ic_fruits),            // 23

        // SNACKS (3) → 26
        ItemTemplate("Chips Pack", 20.0, R.drawable.ic_snacks),            // 24
        ItemTemplate("Namkeen 500g", 65.0, R.drawable.ic_snacks),          // 25
        ItemTemplate("Biscuit Pack", 30.0, R.drawable.ic_snacks),          // 26

        // OIL (2) → 28
        ItemTemplate("Sunflower Oil 1L", 140.0, R.drawable.ic_oil),        // 27
        ItemTemplate("Mustard Oil 1L", 150.0, R.drawable.ic_oil),          // 28

        // CLEANING (2) → 30
        ItemTemplate("Dishwash Liquid 500ml", 55.0, R.drawable.ic_cleaning), // 29
        ItemTemplate("Floor Cleaner 1L", 90.0, R.drawable.ic_cleaning)       // 30
    )

    private fun initSampleData() {
        if (shops.isNotEmpty()) return

        val names = listOf("GreenMart", "DailyNeeds", "Fresh Basket", "UrbanGrocer", "BudgetBazaar")
        val owners = listOf("Owner A", "Owner B", "Owner C", "Owner D", "Owner E")
        val coords = listOf(
            28.6000 to 77.3500,
            28.6050 to 77.3550,
            28.6100 to 77.3600,
            28.6150 to 77.3650,
            28.6200 to 77.3700
        )

        val templates = groceryTemplates()

        for (i in 0 until 5) {
            val shop = Shop(
                id = i + 1,
                name = names[i],
                ownerName = owners[i],
                city = "Noida",
                latitude = coords[i].first,
                longitude = coords[i].second
            )

            // 30 items per shop, with UNIQUE NAMES for each shop
            for (j in templates.indices) {
                val t = templates[j]

                shop.items += Item(
                    id = nextItemId++,
                    shopId = shop.id,
                    name = "${t.name} - ${shop.name}",      // <-- UNIQUE NAME PER SHOP
                    price = t.price,
                    quantity = 10 + ((j + i) % 7) * 3,      // slightly varied stock per shop
                    iconResId = t.iconResId
                )
            }

            shops += shop
        }
    }

    // ---------- ITEM MANAGEMENT ----------

    fun getShops(): List<Shop> = shops

    fun getShopById(id: Int): Shop? = shops.find { it.id == id }

    fun getAllItems(): List<Item> = shops.flatMap { it.items }

    fun addItem(shopId: Int, name: String, price: Double, quantity: Int) {
        val shop = getShopById(shopId) ?: return
        val item = Item(
            id = nextItemId++,
            shopId = shopId,
            name = name,
            price = price,
            quantity = quantity,
            iconResId = guessIconForName(name)
        )
        shop.items.add(0, item)
    }

    fun updateItem(shopId: Int, itemId: Int, newName: String, newPrice: Double, newQuantity: Int) {
        val item = findItem(shopId, itemId) ?: return
        item.name = newName
        item.price = newPrice
        item.quantity = newQuantity
    }

    fun removeItem(shopId: Int, itemId: Int) {
        val shop = getShopById(shopId) ?: return
        shop.items.removeAll { it.id == itemId }
        cart.removeAll { it.shopId == shopId && it.itemId == itemId }
    }

    fun findItem(shopId: Int, itemId: Int): Item? =
        getShopById(shopId)?.items?.find { it.id == itemId }

    // ---------- AUTO ICON SELECTION ----------

    private fun guessIconForName(name: String): Int {
        val n = name.lowercase()

        return when {
            listOf("rice", "atta", "dal", "poha", "oats").any { n.contains(it) } ->
                R.drawable.ic_grains

            listOf("milk", "curd", "paneer", "cheese").any { n.contains(it) } ->
                R.drawable.ic_dairy

            listOf("potato", "onion", "tomato").any { n.contains(it) } ->
                R.drawable.ic_veggies

            listOf("apple", "banana", "orange").any { n.contains(it) } ->
                R.drawable.ic_fruits

            listOf("chips", "namkeen", "biscuit").any { n.contains(it) } ->
                R.drawable.ic_snacks

            listOf("oil", "mustard", "ghee").any { n.contains(it) } ->
                R.drawable.ic_oil

            listOf("cleaner", "dishwash", "detergent").any { n.contains(it) } ->
                R.drawable.ic_cleaning

            else -> R.drawable.ic_grains
        }
    }

    // ---------- CART ----------

    fun getCart(): List<CartItem> = cart

    fun getCartSize(): Int = cart.sumOf { it.quantity }

    fun addToCart(shopId: Int, itemId: Int, quantity: Int) {
        if (quantity <= 0) return
        val existing = cart.find { it.shopId == shopId && it.itemId == itemId }
        if (existing != null) existing.quantity += quantity
        else cart += CartItem(shopId, itemId, quantity)
    }

    fun updateCartQuantity(shopId: Int, itemId: Int, quantity: Int) {
        val existing = cart.find { it.shopId == shopId && it.itemId == itemId } ?: return
        if (quantity <= 0) cart.remove(existing) else existing.quantity = quantity
    }

    fun removeFromCart(shopId: Int, itemId: Int) {
        cart.removeAll { it.shopId == shopId && it.itemId == itemId }
    }

    fun clearCart() = cart.clear()

    // ---------- DISTANCE & ETA ----------

    data class ShopEta(val shop: Shop, val distanceKm: Double, val etaMinutes: Int)

    fun calculateEtasForCart(customerLat: Double, customerLng: Double): List<ShopEta> {
        if (cart.isEmpty()) return emptyList()

        val involvedShops = cart.map { it.shopId }.toSet()

        return involvedShops.mapNotNull { sid ->
            val shop = getShopById(sid) ?: return@mapNotNull null
            val dist = haversineKm(customerLat, customerLng, shop.latitude, shop.longitude)
            val etaMin = ((dist / 25.0) * 60 + 10).roundToInt().coerceAtLeast(10)
            ShopEta(shop, dist, etaMin)
        }.sortedBy { it.distanceKm }
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat/2).pow(2) + cos(Math.toRadians(lat1)) *
                cos(Math.toRadians(lat2)) * sin(dLon/2).pow(2)
        return 2 * R * atan2(sqrt(a), sqrt(1 - a))
    }

    // ---------- ORDER SYSTEM (ATOMIC) ----------

    data class PlaceOrderResult(
        val success: Boolean,
        val message: String,
        val createdOrders: List<Order> = emptyList()
    )

    fun placeOrder(customerLat: Double, customerLng: Double): PlaceOrderResult {
        if (cart.isEmpty()) return PlaceOrderResult(false, "Cart is empty.")

        // 1 — Stock check (atomic)
        for (ci in cart) {
            val item = findItem(ci.shopId, ci.itemId)
                ?: return PlaceOrderResult(false, "Item not found.")
            if (ci.quantity > item.quantity) {
                return PlaceOrderResult(
                    false,
                    "Not enough stock for '${item.name}'. Requested ${ci.quantity}, available ${item.quantity}."
                )
            }
        }

        // 2 — Group orders by shop
        val grouped = cart.groupBy { it.shopId }
        val created = mutableListOf<Order>()

        for ((shopId, groupItems) in grouped) {
            val shop = getShopById(shopId) ?: return PlaceOrderResult(false, "Shop missing.")

            val distance = haversineKm(customerLat, customerLng, shop.latitude, shop.longitude)
            val eta = ((distance / 25.0) * 60 + 10).roundToInt().coerceAtLeast(10)

            val orderItems = groupItems.map { ci ->
                val item = findItem(shopId, ci.itemId)!!
                OrderItem(item.name, ci.quantity, item.price)
            }

            val total = orderItems.sumOf { it.quantity * it.priceEach }

            created += Order(
                id = nextOrderId++,
                shopId = shopId,
                totalAmount = total,
                distanceKm = distance,
                etaMinutes = eta,
                items = orderItems,
                customerLat = customerLat,
                customerLng = customerLng
            )
        }

        // 3 — deduct stock
        for (ci in cart) {
            findItem(ci.shopId, ci.itemId)!!.quantity -= ci.quantity
        }

        // 4 — save orders + clear cart
        orders += created
        cart.clear()

        return PlaceOrderResult(true, "Order placed successfully.", created)
    }

    fun getOrdersForShop(shopId: Int): List<Order> =
        orders.filter { it.shopId == shopId }.sortedByDescending { it.timestampMillis }
}
