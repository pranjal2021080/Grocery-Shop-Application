package com.example.groceryshopapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.res.painterResource
import com.example.groceryshopapp.data.AppRepository
import com.example.groceryshopapp.data.UserRole
import com.example.groceryshopapp.model.CartItem
import com.example.groceryshopapp.model.Item
import com.example.groceryshopapp.model.Order
import com.example.groceryshopapp.ui.theme.GroceryShopAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GroceryShopAppTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        GroceryAppRoot()
                    }
                }
            }
        }
    }
}

// ---------- Simple navigation state ----------

sealed class Screen {
    object RoleSelection : Screen()
    object CustomerHome : Screen()
    object Cart : Screen()
    data class OwnerDashboard(val shopId: Int) : Screen()
    data class ShopItems(val shopId: Int) : Screen()
}

@Composable
fun GroceryAppRoot() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.RoleSelection) }

    when (val screen = currentScreen) {
        Screen.RoleSelection ->
            RoleSelectionScreen(
                onCustomer = { currentScreen = Screen.CustomerHome },
                onOwnerSelected = { shopId ->
                    currentScreen = Screen.OwnerDashboard(shopId)
                }
            )

        Screen.CustomerHome ->
            CustomerHomeScreen(
                onBack = { currentScreen = Screen.RoleSelection },
                onGoToCart = { currentScreen = Screen.Cart },
                onOpenShop = { shopId -> currentScreen = Screen.ShopItems(shopId) }
            )

        Screen.Cart ->
            CartScreen(
                onBack = { currentScreen = Screen.CustomerHome }
            )

        is Screen.OwnerDashboard ->
            OwnerDashboardScreen(
                shopId = screen.shopId,
                onBack = { currentScreen = Screen.RoleSelection }
            )

        is Screen.ShopItems ->
            ShopItemsScreen(
                shopId = screen.shopId,
                onBack = { currentScreen = Screen.CustomerHome },
                onGoToCart = { currentScreen = Screen.Cart }   // cart opens directly
            )
    }
}

// ---------- Role selection ----------

@Composable
fun RoleSelectionScreen(
    onCustomer: () -> Unit,
    onOwnerSelected: (Int) -> Unit
) {
    var isCustomerLogin by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Grocery Shop App",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(25.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { isCustomerLogin = true },
                colors = if (isCustomerLogin)
                    ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary)
                else ButtonDefaults.buttonColors(MaterialTheme.colorScheme.secondary)
            ) {
                Text("Customer Login")
            }

            Button(
                onClick = { isCustomerLogin = false },
                colors = if (!isCustomerLogin)
                    ButtonDefaults.buttonColors(MaterialTheme.colorScheme.primary)
                else ButtonDefaults.buttonColors(MaterialTheme.colorScheme.secondary)
            ) {
                Text("Shop Owner Login")
            }
        }

        Spacer(Modifier.height(25.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val role = if (isCustomerLogin) UserRole.CUSTOMER else UserRole.OWNER
                val success = AppRepository.login(username, password, role)

                if (!success) {
                    errorText = "Incorrect username or password"
                    return@Button
                }

                errorText = null
                val user = AppRepository.getCurrentUser()

                if (role == UserRole.CUSTOMER) {
                    onCustomer()
                } else {
                    val shopId = user?.shopId
                    if (shopId != null) {
                        onOwnerSelected(shopId)
                    } else {
                        errorText = "This owner has no shop assigned."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }

        Spacer(Modifier.height(10.dp))

        if (isCustomerLogin) {
            TextButton(onClick = {
                username = ""
                password = ""
                AppRepository.logout()
                onCustomer()
            }) {
                Text("Continue as Guest Customer")
            }
        }

        if (errorText != null) {
            Spacer(Modifier.height(12.dp))
            Text(
                text = errorText!!,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

// ---------- Customer side ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerHomeScreen(
    onBack: () -> Unit,
    onGoToCart: () -> Unit,
    onOpenShop: (Int) -> Unit
) {
    val shops = remember { AppRepository.getShops() }
    val allItems = remember { AppRepository.getAllItems() }
    var selectedTab by remember { mutableStateOf(0) } // 0 = shops, 1 = all items

    var cartSize by remember { mutableIntStateOf(AppRepository.getCartSize()) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Customer") },
            navigationIcon = {
                TextButton(onClick = onBack) { Text("Back") }
            },
            actions = {
                Button(onClick = onGoToCart) {
                    Text("Cart ($cartSize)")
                }
            }
        )

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("By Shop", modifier = Modifier.padding(8.dp))
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("All Items", modifier = Modifier.padding(8.dp))
            }
        }

        if (selectedTab == 0) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                items(shops) { shop ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .clickable { onOpenShop(shop.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(shop.name, fontWeight = FontWeight.Bold)
                                Text(shop.city)
                            }
                            Text(text = "${shop.items.size} items")
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                items(allItems) { item ->
                    ItemRowForCustomer(
                        item = item,
                        onAdded = {
                            cartSize = AppRepository.getCartSize()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ItemRowForCustomer(
    item: Item,
    onAdded: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = item.iconResId),
                contentDescription = item.name,
                modifier = Modifier
                    .size(40.dp)
                    .padding(end = 8.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Bold)
                Text("Price: ₹${item.price}")
                Text("Stock: ${item.quantity}")
            }
            Button(
                onClick = {
                    AppRepository.addToCart(item.shopId, item.id, 1)
                    onAdded()   // instant cart count update in top bar
                }
            ) {
                Text("Add")
            }
        }
    }
}

// ---------- Shop items (per shop) ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopItemsScreen(
    shopId: Int,
    onBack: () -> Unit,
    onGoToCart: () -> Unit
) {
    val shop = remember { AppRepository.getShopById(shopId) }
    var items by remember { mutableStateOf(shop?.items?.toList() ?: emptyList()) }

    var cartSize by remember { mutableIntStateOf(AppRepository.getCartSize()) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(shop?.name ?: "Shop") },
            navigationIcon = {
                TextButton(onClick = onBack) { Text("Back") }
            },
            actions = {
                Button(onClick = onGoToCart) {
                    Text("Cart ($cartSize)")
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            items(items) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = item.iconResId),
                            contentDescription = item.name,
                            modifier = Modifier
                                .size(40.dp)
                                .padding(end = 8.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.Bold)
                            Text("Price: ₹${item.price}")
                            Text("Stock: ${item.quantity}")
                        }
                        Button(
                            onClick = {
                                AppRepository.addToCart(item.shopId, item.id, 1)
                                cartSize = AppRepository.getCartSize()
                            }
                        ) {
                            Text("Add")
                        }
                    }
                }
            }
        }
    }
}

// ---------- Cart + atomic order + ETA ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    onBack: () -> Unit
) {
    var cartItems by remember { mutableStateOf(AppRepository.getCart().map { it.copy() }) }
    var latText by remember { mutableStateOf("28.6") }
    var lngText by remember { mutableStateOf("77.2") }
    var message by remember { mutableStateOf("") }
    var lastOrders by remember { mutableStateOf<List<Order>>(emptyList()) }
    var lastBillAmount by remember { mutableStateOf<Double?>(null) }

    fun refreshCart() {
        cartItems = AppRepository.getCart().map { it.copy() }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Cart") },
            navigationIcon = {
                TextButton(onClick = onBack) { Text("Back") }
            }
        )

        // ---- Cart list / empty state area ----
        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val text = if (lastOrders.isEmpty()) {
                    "Your cart is empty."
                } else {
                    "Your cart is now empty.\nSee order summary below."
                }
                Text(text)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp)
            ) {
                items(cartItems) { ci ->
                    val item = AppRepository.findItem(ci.shopId, ci.itemId)
                    if (item != null) {
                        CartItemRow(
                            cartItem = ci,
                            item = item,
                            onQuantityChange = { newQty ->
                                AppRepository.updateCartQuantity(ci.shopId, ci.itemId, newQty)
                                refreshCart()
                            },
                            onRemove = {
                                AppRepository.removeFromCart(ci.shopId, ci.itemId)
                                refreshCart()
                            }
                        )
                    }
                }
            }
        }

        // current cart total (will be 0 after order, but we keep lastBillAmount separately)
        val currentCartTotal = cartItems.sumOf { ci ->
            val item = AppRepository.findItem(ci.shopId, ci.itemId)
            (item?.price ?: 0.0) * ci.quantity
        }

        val lat = latText.toDoubleOrNull() ?: 0.0
        val lng = lngText.toDoubleOrNull() ?: 0.0
        val etas = AppRepository.calculateEtasForCart(lat, lng)

        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Current Cart Total: ₹${"%.2f".format(currentCartTotal)}",
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = latText,
                onValueChange = { latText = it },
                label = { Text("Customer Latitude") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = lngText,
                onValueChange = { lngText = it },
                label = { Text("Customer Longitude") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))

            if (etas.isNotEmpty()) {
                Text(
                    text = "Estimated Delivery (per shop):",
                    fontWeight = FontWeight.SemiBold
                )
                etas.forEach { eta ->
                    Text(
                        text = "- ${eta.shop.name}: " +
                                String.format("%.1f km, ~%d min", eta.distanceKm, eta.etaMinutes)
                    )
                }
                Spacer(Modifier.height(8.dp))
            }

            if (message.isNotBlank()) {
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
            }

            Button(
                onClick = {
                    val result = AppRepository.placeOrder(lat, lng)
                    message = result.message
                    lastOrders = result.createdOrders
                    lastBillAmount = result.createdOrders.sumOf { it.totalAmount }
                    refreshCart()  // cart becomes empty, but we *still* show summary below
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Place Order (Atomic Check)")
            }

            if (lastOrders.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Orders created (per shop):", fontWeight = FontWeight.SemiBold)
                lastOrders.forEach { order ->
                    Text(
                        text = "- Shop ${order.shopId}: " +
                                String.format(
                                    "₹%.2f, %.1f km, ~%d min",
                                    order.totalAmount,
                                    order.distanceKm,
                                    order.etaMinutes
                                )
                    )
                }

                lastBillAmount?.let { amt ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Total Bill for this Order: ₹${"%.2f".format(amt)}",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    cartItem: CartItem,
    item: Item,
    onQuantityChange: (Int) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = item.iconResId),
                contentDescription = item.name,
                modifier = Modifier
                    .size(40.dp)
                    .padding(end = 8.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Bold)
                Text("Price: ₹${item.price}")
                Text("In stock: ${item.quantity}")
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val newQty = (cartItem.quantity - 1).coerceAtLeast(0)
                        onQuantityChange(newQty)
                    }) {
                        Text("-")
                    }
                    Text(
                        text = cartItem.quantity.toString(),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Button(onClick = {
                        val newQty = cartItem.quantity + 1
                        onQuantityChange(newQty)
                    }) {
                        Text("+")
                    }
                }
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onRemove) {
                    Text("Remove")
                }
            }
        }
    }
}

// ---------- Owner side (fixed) ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerDashboardScreen(
    shopId: Int,
    onBack: () -> Unit
) {
    // Use a state list so mutations trigger recomposition even if elements are same objects
    val items = remember { mutableStateListOf<Item>() }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<Item?>(null) }

    // Helper to reload items from repository (newest first because addItem inserts at index 0)
    fun reloadItems() {
        items.clear()
        val latest = AppRepository.getShopById(shopId)?.items ?: emptyList()
        items.addAll(latest)
    }

    // initial load
    LaunchedEffect(shopId) {
        reloadItems()
    }

    // Orders snapshot (simple dashboard)
    val orders by remember { mutableStateOf(AppRepository.getOrdersForShop(shopId)) }

    val shopName = AppRepository.getShopById(shopId)?.name ?: "Owner"

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(shopName) },
            navigationIcon = {
                TextButton(onClick = onBack) { Text("Back") }
            }
        )

        Text(
            text = "Inventory",
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(12.dp)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        ) {
            // key by id so Compose tracks each item properly
            items(items, key = { it.id }) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = item.iconResId),
                            contentDescription = item.name,
                            modifier = Modifier
                                .size(40.dp)
                                .padding(end = 8.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.Bold)
                            Text("Price: ₹${item.price}")
                            Text("Stock: ${item.quantity}")
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(onClick = { editingItem = item }) {
                                Text("Edit")
                            }
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = {
                                AppRepository.removeItem(shopId, item.id)
                                reloadItems()   // refresh immediately after delete
                            }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            Text("Add New Item")
        }

        Spacer(Modifier.height(12.dp))

        Text(
            text = "Recent Orders",
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        LazyColumn(
            modifier = Modifier
                .heightIn(max = 200.dp)
                .padding(8.dp)
        ) {
            items(orders) { order ->
                OrderRow(order = order)
            }
        }

        if (showAddDialog) {
            ItemEditDialog(
                title = "Add Item",
                initialName = "",
                initialPrice = "",
                initialQty = "",
                onDismiss = { showAddDialog = false },
                onConfirm = { name, price, qty ->
                    AppRepository.addItem(
                        shopId,
                        name,
                        price.toDoubleOrNull() ?: 0.0,
                        qty.toIntOrNull() ?: 0
                    )
                    reloadItems()       // new item appears at top immediately
                    showAddDialog = false
                }
            )
        }

        editingItem?.let { item ->
            ItemEditDialog(
                title = "Edit Item",
                initialName = item.name,
                initialPrice = item.price.toString(),
                initialQty = item.quantity.toString(),
                onDismiss = { editingItem = null },
                onConfirm = { name, price, qty ->
                    AppRepository.updateItem(
                        shopId = shopId,
                        itemId = item.id,
                        newName = name,
                        newPrice = price.toDoubleOrNull() ?: item.price,
                        newQuantity = qty.toIntOrNull() ?: item.quantity
                    )
                    reloadItems()       // edited values reflected instantly
                    editingItem = null
                }
            )
        }
    }
}

@Composable
fun ItemEditDialog(
    title: String,
    initialName: String,
    initialPrice: String,
    initialQty: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var price by remember { mutableStateOf(initialPrice) }
    var qty by remember { mutableStateOf(initialQty) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") }
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("Price") }
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it },
                    label = { Text("Quantity") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name, price, qty) }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun OrderRow(order: Order) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Order #${order.id}",
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Total: ₹${"%.2f".format(order.totalAmount)} | " +
                        "Distance: ${"%.1f".format(order.distanceKm)} km | " +
                        "ETA: ~${order.etaMinutes} min"
            )
            if (order.items.isNotEmpty()) {
                val first = order.items.first()
                val more = order.items.size - 1
                val line = if (more > 0) {
                    "${first.quantity}× ${first.itemName} + $more more"
                } else {
                    "${first.quantity}× ${first.itemName}"
                }
                Text(
                    text = line,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
